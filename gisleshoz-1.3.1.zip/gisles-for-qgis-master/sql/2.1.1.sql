INSERT INTO dictionary.xmer (code_xmer, name_xmer) VALUES(115, NULL);
INSERT INTO dictionary.xmer (code_xmer, name_xmer) VALUES(116, NULL);